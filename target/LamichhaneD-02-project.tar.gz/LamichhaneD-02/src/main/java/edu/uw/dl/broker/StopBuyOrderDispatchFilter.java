///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package edu.uw.dl.broker;
//
//import edu.uw.ext.framework.order.StopBuyOrder;
//import java.util.function.BiPredicate;
//
///**
// *
// * @author dixya
// */
//public class StopBuyOrderDispatchFilter implements BiPredicate<Integer, StopBuyOrder>{
//
//    @Override
//    public boolean test(Integer t, StopBuyOrder u) {
//        return u.getPrice() <= t;
//    }
//    
//}
